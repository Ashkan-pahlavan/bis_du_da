import cv2
import time
import os
import numpy as np
from datetime import datetime
from sklearn.neighbors import KNeighborsClassifier
import pickle
import csv
import threading
from win32com.client import Dispatch

# Function to speak out messages (if needed)
def speak(message):
    speak = Dispatch("SAPI.SpVoice")
    speak.Speak(message)

# Load models and data
facedetect = cv2.CascadeClassifier('data/haarcascade_frontalface_default.xml')
with open('data/names.pkl', 'rb') as w:
    LABELS = pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)
imgBackground = cv2.imread("background.png")
COL_NAMES = ['NAME', 'TIME']

def process_frame(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)
    attendance = []
    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w, :]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
        output = knn.predict(resized_img)
        ts = time.time()
        date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
        timestamp = datetime.fromtimestamp(ts).strftime("%H:%M-%S")
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 1)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (50, 50, 255), 2)
        cv2.rectangle(frame, (x, y-40), (x+w, y), (50, 50, 255), -1)
        cv2.putText(frame, str(output[0]), (x, y-15), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
        attendance = [str(output[0]), str(timestamp)]
    return frame, attendance

def capture_frame():
    video = cv2.VideoCapture(0, cv2.CAP_DSHOW)  # Use DirectShow backend
    ret, frame = video.read()
    video.release()
    if not ret:
        print("Failed to capture frame")
        return None
    return frame

def periodic_capture():
    global frame, capture_requested
    while True:
        if capture_requested:
            frame = capture_frame()
            capture_requested = False
        time.sleep(0.5)

capture_interval = 900  # Capture frame every 900 seconds (15 minutes)
start_time = time.time()
frame = None
capture_requested = False
attendance_data = []

# Start the thread for periodic capture
thread = threading.Thread(target=periodic_capture)
thread.start()

while True:
    if time.time() - start_time >= capture_interval:
        capture_requested = True
        start_time = time.time()
    if frame is not None:
        processed_frame, attendance = process_frame(frame)
        imgBackground[162:162 + 480, 55:55 + 640] = processed_frame
        cv2.imshow("Frame", imgBackground)
        if attendance:
            attendance_data.append(attendance)
        date = datetime.fromtimestamp(time.time()).strftime("%d-%m-%Y")
        if len(attendance_data) > 0:
            exist = os.path.isfile("Attendance/Attendance_" + date + ".csv")
            if exist:
                with open("Attendance/Attendance_" + date + ".csv", "a") as csvfile:
                    writer = csv.writer(csvfile)
                    writer.writerows(attendance_data)
            else:
                with open("Attendance/Attendance_" + date + ".csv", "a") as csvfile:
                    writer = csv.writer(csvfile)
                    writer.writerow(COL_NAMES)
                    writer.writerows(attendance_data)
            attendance_data = []  # Clear the cached data after writing
    k = cv2.waitKey(1)
    if k == ord('q'):
        break
cv2.destroyAllWindows()
